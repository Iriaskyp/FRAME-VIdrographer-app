# FRAME — Videographer Android App

This is a complete Android Studio project that packages the FRAME cinematic
videographer portfolio as a native Android APK using Kotlin + WebView.

## Build the APK

1. Install Android Studio.
2. Open this entire `FRAME_Videographer_Android` folder.
3. Allow Android Studio to sync/download the Android Gradle Plugin and SDK.
4. Select:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
5. Android Studio will create the debug APK under:
   app/build/outputs/apk/debug/app-debug.apk

## Install on an Android phone

Copy `app-debug.apk` to the phone and open it. Android may ask you to allow
installation from that source.

## Customize before publishing

Change these in `app/src/main/assets/index.html`:
- FRAME name
- email address
- Instagram/Vimeo/YouTube links
- project names
- project descriptions
- images

Replace the Unsplash image URLs with your own images for a fully branded app.

## Publishing

For Google Play, create a signed release build in Android Studio:
Build > Generate Signed App Bundle / APK

For Play Store, an Android App Bundle (.aab) is normally used instead of APK.

Package ID:
com.frame.studio

App name:
FRAME

Version:
1.0