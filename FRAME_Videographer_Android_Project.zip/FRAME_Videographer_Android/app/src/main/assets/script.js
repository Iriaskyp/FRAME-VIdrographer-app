
const menu=document.getElementById("menu"),nav=document.getElementById("nav");
menu.onclick=()=>nav.classList.toggle("open");
document.querySelectorAll("nav a").forEach(a=>a.onclick=()=>nav.classList.remove("open"));

const buttons=document.querySelectorAll(".filters button"), cards=document.querySelectorAll(".card");
buttons.forEach(btn=>btn.onclick=()=>{
 buttons.forEach(b=>b.classList.remove("active")); btn.classList.add("active");
 const f=btn.dataset.filter;
 cards.forEach(c=>c.style.display=(f==="all"||c.dataset.category===f)?"block":"none");
});
